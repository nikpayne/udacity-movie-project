# Movie Project

## DESCRIPTION
Fresh Tomatoes! is app allows you to view and watch a list of movie trailers.

## TO RUN THE FILE
1) Download the movie-list.zip file
2) Unzip the file
3) Enter the "movie-list" main directory using $ _cd movie-list_
4) To run the file, type $ _python entertainment_center.py_ in the command line
5) The browser will display "Fresh Tomatoes!" in a new tab
6) To exit the program, simply close the tab
